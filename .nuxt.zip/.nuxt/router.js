import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _7f9b289e = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages/about" */))
const _4b7b1827 = () => interopDefault(import('..\\pages\\auth.vue' /* webpackChunkName: "pages/auth" */))
const _62a445be = () => interopDefault(import('..\\pages\\blog.vue' /* webpackChunkName: "pages/blog" */))
const _655ab7ca = () => interopDefault(import('..\\pages\\blog-article.vue' /* webpackChunkName: "pages/blog-article" */))
const _55aebd10 = () => interopDefault(import('..\\pages\\casino-profile.vue' /* webpackChunkName: "pages/casino-profile" */))
const _06ff7d78 = () => interopDefault(import('..\\pages\\concierge.vue' /* webpackChunkName: "pages/concierge" */))
const _07f04d71 = () => interopDefault(import('..\\pages\\contact.vue' /* webpackChunkName: "pages/contact" */))
const _57ee01cc = () => interopDefault(import('..\\pages\\cookie-policy.vue' /* webpackChunkName: "pages/cookie-policy" */))
const _72c1b3bb = () => interopDefault(import('..\\pages\\create.vue' /* webpackChunkName: "pages/create" */))
const _50db555c = () => interopDefault(import('..\\pages\\custom-trip.vue' /* webpackChunkName: "pages/custom-trip" */))
const _6e6d9caa = () => interopDefault(import('..\\pages\\custom-trip-step1.vue' /* webpackChunkName: "pages/custom-trip-step1" */))
const _84e620b6 = () => interopDefault(import('..\\pages\\dashboard.vue' /* webpackChunkName: "pages/dashboard" */))
const _53247c42 = () => interopDefault(import('..\\pages\\destination.vue' /* webpackChunkName: "pages/destination" */))
const _68faa67a = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _7f83ae32 = () => interopDefault(import('..\\pages\\menu-app.vue' /* webpackChunkName: "pages/menu-app" */))
const _5d144450 = () => interopDefault(import('..\\pages\\message.vue' /* webpackChunkName: "pages/message" */))
const _634a0fcc = () => interopDefault(import('..\\pages\\password.vue' /* webpackChunkName: "pages/password" */))
const _25bbcf71 = () => interopDefault(import('..\\pages\\physical-education.vue' /* webpackChunkName: "pages/physical-education" */))
const _e0844d54 = () => interopDefault(import('..\\pages\\privacy-policy.vue' /* webpackChunkName: "pages/privacy-policy" */))
const _00887ae3 = () => interopDefault(import('..\\pages\\recover-password.vue' /* webpackChunkName: "pages/recover-password" */))
const _a70de886 = () => interopDefault(import('..\\pages\\terms-conditions.vue' /* webpackChunkName: "pages/terms-conditions" */))
const _9c7c0bde = () => interopDefault(import('..\\pages\\test.vue' /* webpackChunkName: "pages/test" */))
const _cf0d1b78 = () => interopDefault(import('..\\pages\\twitter.vue' /* webpackChunkName: "pages/twitter" */))
const _ba143d8c = () => interopDefault(import('..\\pages\\userdashboard.vue' /* webpackChunkName: "pages/userdashboard" */))
const _c159f93a = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _7f9b289e,
    name: "about"
  }, {
    path: "/auth",
    component: _4b7b1827,
    name: "auth"
  }, {
    path: "/blog",
    component: _62a445be,
    name: "blog"
  }, {
    path: "/blog-article",
    component: _655ab7ca,
    name: "blog-article"
  }, {
    path: "/casino-profile",
    component: _55aebd10,
    name: "casino-profile"
  }, {
    path: "/concierge",
    component: _06ff7d78,
    name: "concierge"
  }, {
    path: "/contact",
    component: _07f04d71,
    name: "contact"
  }, {
    path: "/cookie-policy",
    component: _57ee01cc,
    name: "cookie-policy"
  }, {
    path: "/create",
    component: _72c1b3bb,
    name: "create"
  }, {
    path: "/custom-trip",
    component: _50db555c,
    name: "custom-trip"
  }, {
    path: "/custom-trip-step1",
    component: _6e6d9caa,
    name: "custom-trip-step1"
  }, {
    path: "/dashboard",
    component: _84e620b6,
    name: "dashboard"
  }, {
    path: "/destination",
    component: _53247c42,
    name: "destination"
  }, {
    path: "/login",
    component: _68faa67a,
    name: "login"
  }, {
    path: "/menu-app",
    component: _7f83ae32,
    name: "menu-app"
  }, {
    path: "/message",
    component: _5d144450,
    name: "message"
  }, {
    path: "/password",
    component: _634a0fcc,
    name: "password"
  }, {
    path: "/physical-education",
    component: _25bbcf71,
    name: "physical-education"
  }, {
    path: "/privacy-policy",
    component: _e0844d54,
    name: "privacy-policy"
  }, {
    path: "/recover-password",
    component: _00887ae3,
    name: "recover-password"
  }, {
    path: "/terms-conditions",
    component: _a70de886,
    name: "terms-conditions"
  }, {
    path: "/test",
    component: _9c7c0bde,
    name: "test"
  }, {
    path: "/twitter",
    component: _cf0d1b78,
    name: "twitter"
  }, {
    path: "/userdashboard",
    component: _ba143d8c,
    name: "userdashboard"
  }, {
    path: "/",
    component: _c159f93a,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
