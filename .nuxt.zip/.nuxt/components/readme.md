# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<DestinationSearch>` | `<destination-search>` (components/destination-search.vue)
- `<DialogLogin>` | `<dialog-login>` (components/dialog-login.vue)
- `<GoogleLogin>` | `<google-login>` (components/google-login.vue)
- `<InputSelect>` | `<input-select>` (components/input-select.vue)
- `<KtFooter>` | `<kt-footer>` (components/kt-footer.vue)
- `<KtHeader>` | `<kt-header>` (components/kt-header.vue)
- `<Loading>` | `<loading>` (components/loading.vue)
- `<NuxtLogo>` | `<nuxt-logo>` (components/NuxtLogo.vue)
- `<Subscribe>` | `<subscribe>` (components/subscribe.vue)
- `<TravelExpert>` | `<travel-expert>` (components/travel-expert.vue)
- `<Tutorial>` | `<tutorial>` (components/Tutorial.vue)
- `<DatePicker>` | `<date-picker>` (components/date-picker/index.js)
- `<DateTable>` | `<date-table>` (components/date-picker/src/basic/date-table.vue)
- `<DatePickerSrcBasicMonthTable>` | `<date-picker-src-basic-month-table>` (components/date-picker/src/basic/month-table.vue)
- `<DatePickerSrcBasicTimeSpinner>` | `<date-picker-src-basic-time-spinner>` (components/date-picker/src/basic/time-spinner.vue)
- `<DatePickerSrcBasicYearTable>` | `<date-picker-src-basic-year-table>` (components/date-picker/src/basic/year-table.vue)
- `<DatePickerSrcPickerTimePicker>` | `<date-picker-src-picker-time-picker>` (components/date-picker/src/picker/time-picker.js)
- `<DatePickerSrcPickerTimeSelect>` | `<date-picker-src-picker-time-select>` (components/date-picker/src/picker/time-select.js)
- `<DateRange>` | `<date-range>` (components/date-picker/src/panel/date-range.vue)
- `<Date>` | `<date>` (components/date-picker/src/panel/date.vue)
- `<DatePickerSrcPanelMonthRange>` | `<date-picker-src-panel-month-range>` (components/date-picker/src/panel/month-range.vue)
- `<DatePickerSrcPanelTimeRange>` | `<date-picker-src-panel-time-range>` (components/date-picker/src/panel/time-range.vue)
- `<DatePickerSrcPanelTimeSelect>` | `<date-picker-src-panel-time-select>` (components/date-picker/src/panel/time-select.vue)
- `<DatePickerSrcPanelTime>` | `<date-picker-src-panel-time>` (components/date-picker/src/panel/time.vue)
