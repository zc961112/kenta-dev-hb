export const DestinationSearch = () => import('../..\\components\\destination-search.vue' /* webpackChunkName: "components/destination-search" */).then(c => wrapFunctional(c.default || c))
export const DialogLogin = () => import('../..\\components\\dialog-login.vue' /* webpackChunkName: "components/dialog-login" */).then(c => wrapFunctional(c.default || c))
export const GoogleLogin = () => import('../..\\components\\google-login.vue' /* webpackChunkName: "components/google-login" */).then(c => wrapFunctional(c.default || c))
export const InputSelect = () => import('../..\\components\\input-select.vue' /* webpackChunkName: "components/input-select" */).then(c => wrapFunctional(c.default || c))
export const KtFooter = () => import('../..\\components\\kt-footer.vue' /* webpackChunkName: "components/kt-footer" */).then(c => wrapFunctional(c.default || c))
export const KtHeader = () => import('../..\\components\\kt-header.vue' /* webpackChunkName: "components/kt-header" */).then(c => wrapFunctional(c.default || c))
export const Loading = () => import('../..\\components\\loading.vue' /* webpackChunkName: "components/loading" */).then(c => wrapFunctional(c.default || c))
export const NuxtLogo = () => import('../..\\components\\NuxtLogo.vue' /* webpackChunkName: "components/nuxt-logo" */).then(c => wrapFunctional(c.default || c))
export const Subscribe = () => import('../..\\components\\subscribe.vue' /* webpackChunkName: "components/subscribe" */).then(c => wrapFunctional(c.default || c))
export const TravelExpert = () => import('../..\\components\\travel-expert.vue' /* webpackChunkName: "components/travel-expert" */).then(c => wrapFunctional(c.default || c))
export const Tutorial = () => import('../..\\components\\Tutorial.vue' /* webpackChunkName: "components/tutorial" */).then(c => wrapFunctional(c.default || c))
export const DatePicker = () => import('../..\\components\\date-picker\\index.js' /* webpackChunkName: "components/date-picker" */).then(c => wrapFunctional(c.default || c))
export const DateTable = () => import('../..\\components\\date-picker\\src\\basic\\date-table.vue' /* webpackChunkName: "components/date-table" */).then(c => wrapFunctional(c.default || c))
export const DatePickerSrcBasicMonthTable = () => import('../..\\components\\date-picker\\src\\basic\\month-table.vue' /* webpackChunkName: "components/date-picker-src-basic-month-table" */).then(c => wrapFunctional(c.default || c))
export const DatePickerSrcBasicTimeSpinner = () => import('../..\\components\\date-picker\\src\\basic\\time-spinner.vue' /* webpackChunkName: "components/date-picker-src-basic-time-spinner" */).then(c => wrapFunctional(c.default || c))
export const DatePickerSrcBasicYearTable = () => import('../..\\components\\date-picker\\src\\basic\\year-table.vue' /* webpackChunkName: "components/date-picker-src-basic-year-table" */).then(c => wrapFunctional(c.default || c))
export const DatePickerSrcPickerTimePicker = () => import('../..\\components\\date-picker\\src\\picker\\time-picker.js' /* webpackChunkName: "components/date-picker-src-picker-time-picker" */).then(c => wrapFunctional(c.default || c))
export const DatePickerSrcPickerTimeSelect = () => import('../..\\components\\date-picker\\src\\picker\\time-select.js' /* webpackChunkName: "components/date-picker-src-picker-time-select" */).then(c => wrapFunctional(c.default || c))
export const DateRange = () => import('../..\\components\\date-picker\\src\\panel\\date-range.vue' /* webpackChunkName: "components/date-range" */).then(c => wrapFunctional(c.default || c))
export const Date = () => import('../..\\components\\date-picker\\src\\panel\\date.vue' /* webpackChunkName: "components/date" */).then(c => wrapFunctional(c.default || c))
export const DatePickerSrcPanelMonthRange = () => import('../..\\components\\date-picker\\src\\panel\\month-range.vue' /* webpackChunkName: "components/date-picker-src-panel-month-range" */).then(c => wrapFunctional(c.default || c))
export const DatePickerSrcPanelTimeRange = () => import('../..\\components\\date-picker\\src\\panel\\time-range.vue' /* webpackChunkName: "components/date-picker-src-panel-time-range" */).then(c => wrapFunctional(c.default || c))
export const DatePickerSrcPanelTimeSelect = () => import('../..\\components\\date-picker\\src\\panel\\time-select.vue' /* webpackChunkName: "components/date-picker-src-panel-time-select" */).then(c => wrapFunctional(c.default || c))
export const DatePickerSrcPanelTime = () => import('../..\\components\\date-picker\\src\\panel\\time.vue' /* webpackChunkName: "components/date-picker-src-panel-time" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
